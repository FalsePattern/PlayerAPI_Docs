package api.player.model;

public class ModelPlayerArmor extends net.minecraft.client.model.ModelBiped
{
	public ModelPlayerArmor()
	{
		this(0.0F);
	}

	public ModelPlayerArmor(float paramFloat)
	{
		this(paramFloat, 0.0F, 64, 32);
	}

	public ModelPlayerArmor(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
	{
		super(paramFloat1, paramFloat2, paramInt1, paramInt2);
	}
}