package api.player.model;

public class ModelPlayerArmor extends net.minecraft.client.model.ModelBiped
{
	public ModelPlayerArmor(float paramFloat)
	{
		this(paramFloat, false);
	}

	public ModelPlayerArmor(float paramFloat, boolean paramBoolean)
	{
		super(paramFloat);
	}
}