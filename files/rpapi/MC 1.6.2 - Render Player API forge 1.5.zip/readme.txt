=======================
Render Player API forge
=======================

Version 1.5 for Minecraft 1.6.2

based on Render Player API vanilla 1.1 for Minecraft 1.6.2

by Divisor



Description
===========

Render Player API is a Minecraft Forge core mod which gives client mods access to the client classes "RenderPlayer" aka "bhg" minimizing conflicts between mods.

Additionally it replaces the models inside all instances of RenderPlayer with player specific models that can be accessed via the embedded Player Model API.



Installation
============

Copy the file "RenderPlayerAPI.jar" inside this Player API installation package to the "mods" folder of your Minecraft installation. In case this folder does not exist, install Minecraft Forge (http://www.minecraftforge.net) on your client and start the corresponding "Forge" Minecraft version at least once.

In any case, NEVER forget: ALWAYS back up your stuff!
