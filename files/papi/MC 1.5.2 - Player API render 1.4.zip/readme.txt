=================
Player API render
=================

Version 1.4 for Minecraft 1.5.2

by Divisor



Description
===========

Player API render is an API pack containing one version of "Player API universal" and "Render Player API".

The latest version of Player API render always contains the latest versions of both APIs.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
