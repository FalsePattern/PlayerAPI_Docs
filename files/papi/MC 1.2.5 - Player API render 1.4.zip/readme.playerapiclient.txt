=================
Player API client
=================

Version 1.5 for Minecraft 1.2.5

by Divisor



Description
===========

Player API client is an API which gives client mods access to the client class "EntityPlayerSP" aka "vq" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
