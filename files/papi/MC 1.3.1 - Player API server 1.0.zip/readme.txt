=================
Player API server
=================

Version 1.0 for Minecraft 1.3.1

by Divisor



Description
===========

Player API server is an API which gives server mods access to the server class "EntityPlayerMP" aka "gt" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft_server.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
