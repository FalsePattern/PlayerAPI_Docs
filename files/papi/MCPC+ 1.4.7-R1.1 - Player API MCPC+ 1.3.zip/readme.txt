================
Player API MCPC+
================

Version 1.3 for MCPC+ 1.4.7-R1.1

by Divisor



Description
===========

Player API universal is an API which gives

* client mods access to the client classes "EntityPlayerSP" aka "bag" and "EntityPlayerMP" aka "iq"
* server mods access to the server class and "EntityPlayerMP" aka "iq"

while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "mcpc-plus-1.4.7-R1.1.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
