================
Player API forge
================

Version 1.2 for Minecraft 1.6.4

based on Player API vanilla 1.1 for Minecraft 1.6.4

by Divisor



Description
===========

Player API forge is an Minecraft Forge core mod which gives

* client mods access to the client classes "EntityPlayerSP" aka "bex" and "EntityPlayerMP" aka "jv"
* server mods access to the server class and "EntityPlayerMP" aka "jv"

while minimizing conflicts between mods.



Installation
============

Client
------

Copy the file "PlayerAPI.jar" inside this Player API installation package to the "mods" folder of your Minecraft installation. In case this folder does not exist, install Minecraft Forge (http://www.minecraftforge.net) on your client and start the corresponding "Forge" Minecraft version at least once.

In any case, NEVER forget: ALWAYS back up your stuff!


Server
------

Copy the file "PlayerAPI.jar" inside this Player API installation package to the "mods" folder of your Minecraft server installation. In case this folder does not exist, install Minecraft Forge (http://www.minecraftforge.net) on your server and start it at least once.

In any case, NEVER forget: ALWAYS back up your stuff!
