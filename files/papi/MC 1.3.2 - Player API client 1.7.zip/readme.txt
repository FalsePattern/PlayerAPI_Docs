=================
Player API client
=================

Version 1.7 for Minecraft 1.3.2

by Divisor



Description
===========

Player API client is an API which gives client mods access to the client classes "EntityPlayerSP" aka "auq" and "EntityPlayerMP" aka "gu" while minimizing conflicts between mods.



Incompatibilities
=================

Player API client *is* compatible with Minecraft Forge, just install Player API client *after* Minecraft Forge.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
