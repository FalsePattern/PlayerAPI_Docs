=================
Player API client
=================

Version 1.5 for Minecraft 1.8.1

created by jamioflan
taken over by Divisor



Description
===========

Player API client is an API which gives client mods access to the client class "EntityPlayerSP" aka "qs" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to theit corresponding locations their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
