=================
Player API client
=================

Version 1.2 for Minecraft 1.2.3

by Divisor



Description
===========

Player API client is an API which gives client mods access to the client class "EntityPlayerSP" aka "vm" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
