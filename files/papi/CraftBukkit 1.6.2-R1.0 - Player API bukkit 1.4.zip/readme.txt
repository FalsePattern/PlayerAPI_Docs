=================
Player API bukkit
=================

Version 1.4 for CraftBukkit 1.6.2-R1.0

by Divisor



Description
===========

Player API bukkit is an API which gives bukkit mods access to the server class "EntityPlayer" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "craftbukkit-1.6.2-R1.0.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
