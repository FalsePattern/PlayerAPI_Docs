=================
Player API Server
=================

Version 1.1 for Minecraft 1.8.1

created by jamioflan
taken over by Divisor



Description
===========

Player API server is an API which gives server mods access to the server class "EntityPlayerMP" aka "ek" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to theit corresponding locations their corresponding locations in your "minecraft_server.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
