=================
Player API bukkit
=================

Version 1.3 for CraftBukkit 1.1-R4

by Divisor



Description
===========

Player API bukkit is an API which gives bukkit mods access to the server class "EntityPlayer" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to theit corresponding locations their corresponding locations in your "craftbukkit-1.1-R4.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
