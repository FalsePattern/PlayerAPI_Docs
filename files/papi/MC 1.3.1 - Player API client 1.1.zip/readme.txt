=================
Player API client
=================

Version 1.1 for Minecraft 1.3.1

by Divisor



Description
===========

Player API client is an API which gives client mods access to the client classes "EntityPlayerSP" aka "aup" and "EntityPlayerMP" aka "gt" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
