================
Player API MCPC+
================

Version 1.2 for MCPC+ 1.6.2-R0.2

by Divisor



Description
===========

Player API MCPC+ is an API which gives mods access to the class and "EntityPlayerMP" aka "ju" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "mcpc-plus-1.6.2-R0.2.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
