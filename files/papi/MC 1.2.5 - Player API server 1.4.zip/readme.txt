=================
Player API server
=================

Version 1.4 for Minecraft 1.2.5

by Divisor



Description
===========

Player API server is an API which gives server mods access to the server class "EntityPlayerMP" aka "gi" while minimizing conflicts between mods.



Installation
============

Copy all class files inside this ZIP file to their corresponding locations in your "minecraft_server.jar".

In any case, NEVER forget: ALWAYS back up your stuff!
